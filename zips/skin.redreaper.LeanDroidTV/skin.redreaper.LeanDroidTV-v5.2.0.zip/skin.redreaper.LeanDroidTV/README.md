# KoDroidTV by Avi
KoDroid is the forked version of Droid TV by Digital High using Confluence skin of Kodi
It is inspired on the old Android TV design.Certain design aspects are however different. This still an Alpha project. I am not very good at coding Kodi skins. 
I used Droid TV's skin and updated some aspects so it works on Kodi Leia. It's still pretty bare bones. 
The skin might end up varying from the actual Android TV skin, but I hope to keep it as close as possible to the Android TV interface. 
The package name is stored as skin.avi.KoDroidTV sometimes. 

*Do not use the media folder is included in the repo.Use the zipped media folder,or download the release zips they have the required media folders.*

1/5/20 Update : The Skin has reached a beta release. 
