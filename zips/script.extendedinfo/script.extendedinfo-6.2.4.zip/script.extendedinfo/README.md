# script.extendedinfo
OpenInfo Kodi Add-on
